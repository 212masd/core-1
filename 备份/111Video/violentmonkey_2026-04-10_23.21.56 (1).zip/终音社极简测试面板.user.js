// ==UserScript==
// @name         终音社极简测试面板
// @namespace    test
// @version      1.0
// @description  仅生成悬浮面板，测试是否显示
// @author       You
// @match        *://*/*  // 匹配所有网站，终音社页面必触发
// @grant        GM_addStyle
// @run-at       document-end
// @noframes
// ==/UserScript==

(function() {
    'use strict';

    // 1. 注入极简样式，确保面板显眼
    GM_addStyle(`
        #testGamePanel {
            position: fixed !important;
            left: 20px !important;
            top: 20px !important;
            width: 300px !important;
            height: 400px !important;
            background: #ffffff !important;
            border: 3px solid #1677ff !important; /* 粗蓝色边框，一眼可见 */
            border-radius: 8px !important;
            box-shadow: 0 0 20px rgba(22,119,255,0.5) !important;
            z-index: 999999999 !important; /* 超高层级，不被遮挡 */
            display: block !important; /* 强制显示 */
            padding: 15px !important;
            color: #333 !important;
        }
        #testPanelHeader {
            font-size: 18px !important;
            font-weight: bold !important;
            color: #1677ff !important;
            margin-bottom: 20px !important;
            padding-bottom: 10px !important;
            border-bottom: 1px solid #eee !important;
        }
    `);

    // 2. 创建极简面板DOM，直接插入页面
    const panel = document.createElement('div');
    panel.id = 'testGamePanel';
    panel.innerHTML = `
        <div id="testPanelHeader">终音社测试面板</div>
        <div>面板已成功显示！</div>
        <div>后续可添加功能</div>
    `;
    // 强制添加到页面最外层
    document.body.appendChild(panel);

})();