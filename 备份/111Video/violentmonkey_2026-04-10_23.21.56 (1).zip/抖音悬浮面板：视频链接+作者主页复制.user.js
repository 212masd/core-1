// ==UserScript==
// @name         抖音悬浮面板：视频链接+作者主页复制
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  右下角可拖动悬浮面板，自动显示当前视频链接 + 作者主页分享链接，点击即可复制
// @author       豆包
// @match        *://www.douyin.com/*
// @match        *://v.douyin.com/*
// @grant        GM_setClipboard
// @grant        GM_addStyle
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    // 样式
    GM_addStyle(`
        #dyFloatBox {
            position: fixed;
            width: 320px;
            background: rgba(20, 20, 20, 0.92);
            color: #fff;
            border-radius: 12px;
            padding: 14px 16px;
            font-size: 13px;
            z-index: 9999999;
            right: 20px;
            bottom: 20px;
            box-shadow: 0 0 12px rgba(0,0,0,0.6);
            user-select: none;
            cursor: move;
            box-sizing: border-box;
            backdrop-filter: blur(4px);
        }
        #dyFloatBox .line {
            margin: 10px 0;
        }
        #dyFloatBox .label {
            font-weight: bold;
            color: #ff4e79;
            margin-bottom: 4px;
        }
        #dyFloatBox .link {
            color: #ddd;
            word-break: break-all;
            padding: 4px 0;
        }
        #dyFloatBox .copyBtn {
            display: inline-block;
            background: #ff4e79;
            color: #fff;
            border-radius: 6px;
            padding: 4px 10px;
            font-size: 12px;
            cursor: pointer;
            margin-top: 4px;
        }
        #dyFloatBox .copyBtn:active {
            background: #e63a66;
        }
    `);

    // 创建悬浮面板
    const panel = document.createElement('div');
    panel.id = 'dyFloatBox';
    panel.innerHTML = `
        <div class="line">
            <div class="label">当前视频链接</div>
            <div class="link" id="videoLink">-</div>
            <div class="copyBtn" id="copyVideo">复制视频链接</div>
        </div>
        <div class="line">
            <div class="label">作者主页分享链接</div>
            <div class="link" id="authorLink">-</div>
            <div class="copyBtn" id="copyAuthor">复制作者主页</div>
        </div>
    `;
    document.body.appendChild(panel);

    // 拖拽功能
    let isDrag = false, offX = 0, offY = 0;
    panel.addEventListener('mousedown', e => {
        isDrag = true;
        offX = e.clientX - panel.getBoundingClientRect().left;
        offY = e.clientY - panel.getBoundingClientRect().top;
        panel.style.cursor = 'grabbing';
    });
    document.addEventListener('mousemove', e => {
        if (!isDrag) return;
        panel.style.right = 'auto';
        panel.style.bottom = 'auto';
        panel.style.left = e.clientX - offX + 'px';
        panel.style.top = e.clientY - offY + 'px';
    });
    document.addEventListener('mouseup', () => {
        isDrag = false;
        panel.style.cursor = 'move';
    });

    // 复制按钮
    document.getElementById('copyVideo').onclick = () => {
        const txt = document.getElementById('videoLink').innerText;
        if (txt && txt !== '-') GM_setClipboard(txt);
    };
    document.getElementById('copyAuthor').onclick = () => {
        const txt = document.getElementById('authorLink').innerText;
        if (txt && txt !== '-') GM_setClipboard(txt);
    };

    // 自动获取信息
    setInterval(() => {
        // 视频链接
        let videoUrl = '';
        const canonical = document.querySelector('link[rel="canonical"]');
        if (canonical) videoUrl = canonical.href;
        else videoUrl = location.href;

        // 作者主页
        let authorUrl = '';
        const authorA = document.querySelector('a[href*="/user/"]');
        if (authorA) {
            authorUrl = authorA.href.split('?')[0];
        }

        document.getElementById('videoLink').innerText = videoUrl || '-';
        document.getElementById('authorLink').innerText = authorUrl || '-';
    }, 800);
})();