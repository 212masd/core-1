// ==UserScript==
// @name         视频批量后台打开工具（viewkey专属版1）
// @namespace    http://tampermonkey.net/
// @version      2.2
// @description  左上角按钮触发后显示/view_video.php?viewkey=格式的视频列表，可勾选后台打开
// @author       You
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // ===================== 核心配置 =====================
    const BTN_STYLE = {
        top: '10px',
        left: '10px',
        bgColor: '#007bff',
        textColor: '#fff'
    };
    const PANEL_WIDTH = '400px';
    const MAX_VIDEO_DISPLAY = 50; // 最多显示50个视频，避免页面卡顿
    // 核心：指定要识别的视频链接特征（就是你要的格式）
    const TARGET_VIDEO_LINK = '/view_video.php?viewkey=';

    // ===================== 创建主按钮 =====================
    const mainBtn = document.createElement('div');
    mainBtn.innerText = '📹 选择视频';
    mainBtn.style.cssText = `
        position: fixed;
        top: ${BTN_STYLE.top};
        left: ${BTN_STYLE.left};
        z-index: 999999;
        padding: 8px 12px;
        background: ${BTN_STYLE.bgColor};
        color: ${BTN_STYLE.textColor};
        border-radius: 6px;
        cursor: pointer;
        font-size: 14px;
        user-select: none;
        box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        transition: background 0.2s;
    `;
    mainBtn.onmouseover = () => mainBtn.style.background = '#0056b3';
    mainBtn.onmouseout = () => mainBtn.style.background = BTN_STYLE.bgColor;
    document.body.appendChild(mainBtn);

    // ===================== 创建视频选择面板 =====================
    let panel = null;
    function createVideoPanel(videoList) {
        // 销毁已存在的面板
        if (panel) panel.remove();

        // 创建面板容器
        panel = document.createElement('div');
        panel.style.cssText = `
            position: fixed;
            top: 50px;
            left: 10px;
            width: ${PANEL_WIDTH};
            max-height: 600px;
            background: #fff;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            z-index: 999998;
            padding: 16px;
            overflow-y: auto;
            display: none;
        `;

        // 面板标题 + 操作按钮
        const header = document.createElement('div');
        header.style.cssText = `
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
            padding-bottom: 8px;
            border-bottom: 1px solid #f0f0f0;
        `;
        header.innerHTML = `
            <span style="font-size: 16px; font-weight: 600; color: #333;">可打开的视频 (${videoList.length})</span>
            <div>
                <button id="selectAllBtn" style="margin-right: 8px; padding: 4px 8px; font-size: 12px; cursor: pointer;">全选</button>
                <button id="cancelAllBtn" style="margin-right: 8px; padding: 4px 8px; font-size: 12px; cursor: pointer;">取消全选</button>
                <button id="openSelectedBtn" style="padding: 4px 12px; font-size: 12px; background: #007bff; color: #fff; border: none; border-radius: 4px; cursor: pointer;">后台打开选中</button>
            </div>
        `;
        panel.appendChild(header);

        // 视频列表容器
        const listContainer = document.createElement('div');
        listContainer.style.cssText = `
            display: flex;
            flex-direction: column;
            gap: 8px;
        `;

        // 生成视频列表项（重点：确保名称100%显示）
        videoList.slice(0, MAX_VIDEO_DISPLAY).forEach((video, index) => {
            const item = document.createElement('div');
            item.style.cssText = `
                display: flex;
                align-items: flex-start;
                padding: 8px;
                border-radius: 4px;
                transition: background 0.1s;
            `;
            item.onmouseover = () => item.style.background = '#f9fafb';
            item.onmouseout = () => item.style.background = 'transparent';

            // 复选框
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.id = `video_${index}`;
            checkbox.value = video.url;
            checkbox.style.marginRight = '8px';
            checkbox.style.marginTop = '2px';

            // 视频信息（名称 + 链接）- 重点优化名称显示
            const info = document.createElement('div');
            info.style.cssText = `
                flex: 1;
                font-size: 13px;
                color: #333;
            `;
            // 名称显示：即使短名称也完整展示，超长才截断
            const displayTitle = video.title.length > 35
                ? `${video.title.substring(0, 35)}...`
                : video.title;
            info.innerHTML = `
                <div style="font-weight: 500; margin-bottom: 4px; color: #222;">【${index+1}】${displayTitle}</div>
                <div style="font-size: 11px; color: #666; word-break: break-all; opacity: 0.8;">${video.url.substring(0, 50)}${video.url.length > 50 ? '...' : ''}</div>
            `;

            item.appendChild(checkbox);
            item.appendChild(info);
            listContainer.appendChild(item);
        });

        panel.appendChild(listContainer);
        document.body.appendChild(panel);

        // ===================== 面板按钮事件 =====================
        // 全选
        document.getElementById('selectAllBtn').addEventListener('click', () => {
            const checkboxes = listContainer.querySelectorAll('input[type="checkbox"]');
            checkboxes.forEach(cb => cb.checked = true);
        });

        // 取消全选
        document.getElementById('cancelAllBtn').addEventListener('click', () => {
            const checkboxes = listContainer.querySelectorAll('input[type="checkbox"]');
            checkboxes.forEach(cb => cb.checked = false);
        });

        // 后台打开选中的视频
        document.getElementById('openSelectedBtn').addEventListener('click', () => {
            const checkboxes = listContainer.querySelectorAll('input[type="checkbox"]:checked');
            if (checkboxes.length === 0) {
                alert('请至少选择一个视频！');
                return;
            }

            // 后台打开选中的视频链接（不跳转）
            checkboxes.forEach(cb => {
                window.open(cb.value, '_blank', 'noopener noreferrer');
            });

            alert(`已在后台打开 ${checkboxes.length} 个视频！`);
            panel.style.display = 'none'; // 打开后关闭面板
        });

        return panel;
    }

    // ===================== 提取页面视频信息（核心修改：只识别/view_video.php?viewkey=链接） =====================
    function extractVideoInfo() {
        const videoList = [];
        const urlSet = new Set(); // 去重
        let videoIndex = 1; // 兜底计数

        // ========== 核心：只提取/view_video.php?viewkey=格式的链接 ==========
        document.querySelectorAll('a').forEach(link => {
            const href = link.href;
            // 只筛选包含TARGET_VIDEO_LINK的链接，且去重、确保是http开头
            if (!href || !href.startsWith('http') || !href.includes(TARGET_VIDEO_LINK) || urlSet.has(href)) {
                return;
            }

            // 生成视频名称（优先级：链接文字 → viewkey值 → 兜底命名）
            let title = '';
            // 1. 优先用链接显示的文字
            title = link.textContent?.trim() || '';
            // 2. 从URL提取viewkey值当名称（更易识别）
            if (!title) {
                const viewkeyMatch = href.match(/viewkey=([^&]+)/);
                title = viewkeyMatch ? `viewkey_${viewkeyMatch[1]}` : '';
            }
            // 3. 最终兜底
            title = title || `视频_${videoIndex}`;

            videoList.push({ title, url: href });
            urlSet.add(href);
            videoIndex++;
        });

        return videoList;
    }

    // ===================== 绑定主按钮事件（新增：等待动态加载） =====================
    mainBtn.addEventListener('click', () => {
        // 延迟500ms，确保动态加载的视频元素被提取
        setTimeout(() => {
            const videoList = extractVideoInfo();
            if (videoList.length === 0) {
                alert('当前页面未检测到/view_video.php?viewkey=格式的视频链接！');
                return;
            }

            // 创建并显示面板
            const panel = createVideoPanel(videoList);
            panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
        }, 500);
    });

})();