// ==UserScript==
// @name         去掉网站灰色背景！！！
// @namespace    http://tampermonkey.net/
// @version      0.6
// @description  实在受不了！于11月30日！支持百度贴吧、QQ、网易、微博、搜狐等待去背景灰色！
// @author       imzhi <yxz_blue@126.com>
// @match        https://*.baidu.com/*
// @match        https://www.qq.com/*
// @match        https://www.163.com/*
// @match        https://www.sohu.com/*
// @match        https://www.sina.com.cn/*
// @match        https://weibo.com/*
// @match        https://www.toutiao.com/*
// @match        https://www.hao123.com/*
// @match        https://www.taobao.com/*
// @match        https://www.jd.com/*
// @match        https://*.1688.com/*
// @match        https://www.iqiyi.com/*
// @match        https://www.zhihu.com/*2
// @match        https://www.ifeng.com/*
// @match        http*://www.265.com/*
// @match        http*://www.xinhuanet.com/*
// @match        http*://www.people.com.cn/*
// @match        https://www.huanqiu.com/*
// @match        https://www.cctv.com/*
// @match        https://www.eastmoney.com/*
// @match        http*://www.jrj.com.cn/*
// @match        https://www.thepaper.cn/*
// @match        https://www.youku.com/**
// @match        https://www.4399.com/*
// @match        https://*.58.com/*
// @match        https://www.autohome.com.cn/*
// @match        https://www.smzdm.com/*
// @match        https://www.12306.cn/*
// @match        https://www.tuniu.com/*
// @match        https://www.ctrip.com/*
// @match        https://pixso.cn/*
// @match        https://www.mgtv.com/*
// @match        https://v.qq.com/*
// @match        https://tv.sohu.com/*
// @match        https://youku.com/*
// @match        https://www.youku.com/*
// @match        http*://video.sina.com.cn/*
// @match        http*://www.bilibili.com/*
// @match        http*://www.eastday.com/*
// @match        https://www.hupu.com/*
// @match        https://www.miguvideo.com/*
// @match        https://www.dongqiudi.com/*
// @match        https://www.zhibo8.cc/*
// @match        http*://sports.sina.com.cn/*
// @match        https://36kr.com/*
// @match        http*://www.pconline.com.cn/*
// @match        https://www.pcpop.com/*
// @match        https://www.huxiu.com/*
// @match        https://www.it168.com/*
// @match        https://www.onlinedown.net/*
// @match        http*://www.tgbus.com/*
// @match        http*://www.changyou.com/*
// @match        https://game.qq.com/*
// @match        http*://game.163.com/*
// @match        http*://www.7k7k.com/*
// @match        https://www.qcc.com/*
// @match        https://shenyang.zbj.com/*
// @match        https://www.chinaz.com/*
// @match        https://www.huaweicloud.com/*
// @match        https://www.xiaoe-tech.com/*
// @match        https://www.zhixi.com/*
// @match        https://www.yuque.com/*
// @match        https://www.teambition.com/*
// @match        https://worktile.com/*
// @match        https://www.csdn.net/*
// @match        https://juejin.cn/*
// @match        http*://www.chinaunix.net/*
// @match        https://www.imooc.com/*
// @match        https://www.icourse163.org/*
// @match        https://www.kdocs.cn/*
// @match        https://www.aliyundrive.com/*
// @match        https://www.processon.com/*
// @license      MIT
// @grant        GM_addStyle
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    GM_addStyle('@charset utf-8; ._imzhi_remove_gray_bg { filter: none !important; }');

    addClass(document.querySelector('html'), '_imzhi_remove_gray_bg');

    if (location.host === 'www.qq.com') {
        addClass(document.querySelector('body'), '_imzhi_remove_gray_bg');
    }

    else if (location.host === 'weibo.com') {
        addClass(document.querySelector('.grayTheme'), '_imzhi_remove_gray_bg');
    }

    else if (location.host === 'www.baidu.com') {
        addClass(document.querySelector('.skin-gray-event'), '_imzhi_remove_gray_bg');
    }

    else if (location.host === 'www.sina.com.cn') {
        GM_addStyle('@charset utf-8; body * { filter: none !important; }');
    }

    else if (location.host === 'www.taobao.com') {
        addClass(document.querySelector('body'), '_imzhi_remove_gray_bg');
    }

    else if (location.host.match(/\.1688\.com$/)) {
        addClass(document.querySelector('body'), '_imzhi_remove_gray_bg');
    }

    else if (location.host === 'www.iqiyi.com') {
        setTimeout(() => {
            addClass(document.querySelector('body .gray'), '_imzhi_remove_gray_bg');
        }, 300);
    }

    else if (location.host === 'www.265.com') {
        addClass(document.querySelector('body'), '_imzhi_remove_gray_bg');
    }

    else if (location.host === 'www.jrj.com.cn') {
        GM_addStyle('@charset utf-8; body * { filter: none !important; }');
    }

    else if (location.host === 'www.thepaper.cn') {
        setTimeout(() => {
            addClass(document.querySelector('html'), '_imzhi_remove_gray_bg');
        }, 300);
    }

    else if (location.host === 'www.4399.com') {
        addClass(document.querySelector('body'), '_imzhi_remove_gray_bg');
    }

    else if (location.host === 'www.12306.cn') {
        addClass(document.querySelector('body'), '_imzhi_remove_gray_bg');
    }

    else if (location.host === 'www.mgtv.com') {
        addClass(document.querySelector('body'), '_imzhi_remove_gray_bg');
        GM_addStyle('@charset utf-8; .page-gray .g-page-channel * { filter: none !important; }');
    }

    else if (location.host === 'v.qq.com') {
        setTimeout(() => {
            addClassAll(document.querySelectorAll('.gray-style-remembrance'), '_imzhi_remove_gray_bg');
        }, 600);
    }

    else if (location.host === 'video.sina.com.cn') {
        addClass(document.querySelector('body'), '_imzhi_remove_gray_bg');
    }

    else if (location.host === 'www.eastday.com') {
        addClass(document.querySelector('body'), '_imzhi_remove_gray_bg');
    }

    else if (location.host === 'www.miguvideo.com') {
        addClass(document.querySelector('#sport-channel'), '_imzhi_remove_gray_bg');
    }

    else if (location.host === 'www.dongqiudi.com') {
        addClass(document.querySelector('.container'), '_imzhi_remove_gray_bg');
    }

    else if (location.host === 'sports.sina.com.cn') {
        addClass(document.querySelector('body'), '_imzhi_remove_gray_bg');
    }

    else if (location.host === 'www.tgbus.com') {
        addClass(document.querySelector('#app > .home'), '_imzhi_remove_gray_bg');
    }

    else if (location.host === 'www.7k7k.com') {
        addClass(document.querySelector('body'), '_imzhi_remove_gray_bg');
    }

    else if (location.host === 'worktile.com') {
        addClass(document.querySelector('body'), '_imzhi_remove_gray_bg');
    }

    function removeClass(ele,cName) {
        var arr1 = ele.className.split(' ');
        var arr2 = cName.split(" ");
        for(var i=0;i<arr2.length;i++)for(var j=arr1.length-1;j>=0;j--)(arr2[i]===arr1[j])&&arr1.splice(j,1)
        ele.className = arr1.join(" ")
    }

    function addClass(ele,cName) {
        console.log('addClassaddClassaddClass', ele);
        var arr = ele.className.split(' ').concat(cName.split(" "));
        for(var i=0;i<arr.length;i++){
            for(var k=arr.length-1;k>i;k--){
                (arr[k]==="")&&arr.splice(k,1);
                (arr[i]===arr[k])&&arr.splice(k,1);
            }
        }
        ele.className = arr.join(" ");
    }

    function addClassAll(ele_arr, cName) {
        console.log('addClassAlladdClassAlladdClassAll', ele_arr);
        for (let ele of ele_arr) {
            addClass(ele, cName);
        }
    }
})();