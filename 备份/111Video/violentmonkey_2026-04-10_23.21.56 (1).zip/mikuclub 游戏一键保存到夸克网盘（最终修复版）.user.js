// ==UserScript==
// @name         mikuclub 游戏一键保存到夸克网盘（最终修复版）
// @namespace    mikuclub_fixed
// @version      3.0
// @description  修复抓取失败，正确提取夸克链接，UI精致+防重复标签
// @match        *://www.mikuclub.win/game/pc-game*
// @match        *://pan.quark.cn/s/*
// @grant        GM_openInTab
// @grant        GM_addStyle
// ==/UserScript==

(function() {
    'use strict';

    // 防重复打开标签
    const processing = new Set();
    const PROCESS_LOCK_SECONDS = 30;

    // 精美UI样式
    GM_addStyle(`
        #miku-pannel * {
            margin:0; padding:0; box-sizing:border-box;
            font-family: "Microsoft YaHei", sans-serif;
        }
        #miku-toggle {
            position: fixed;
            bottom: 20px; left: 20px;
            z-index: 999999;
            width: 52px; height: 52px;
            border-radius: 50%;
            background: rgba(33, 115, 232, 0.9);
            backdrop-filter: blur(10px);
            color: #fff;
            font-size: 22px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(33,115,232,0.3);
            transition: all 0.3s ease;
        }
        #miku-toggle:hover {
            transform: scale(1.1);
            background: rgba(33,115,232,1);
        }
        #miku-game-box {
            position: fixed;
            bottom: 84px; left: 20px;
            z-index: 999998;
            width: 390px;
            max-height: 65vh;
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(12px);
            border-radius: 16px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.1);
            padding: 16px;
            overflow-y: auto;
            display: none;
        }
        .game-item {
            padding: 12px;
            margin-bottom: 8px;
            background: #f7f9fc;
            border-radius: 10px;
            cursor: pointer;
            transition: background 0.2s;
        }
        .game-item:hover {
            background: #eef5ff;
        }
        .game-title {
            font-weight: 500;
            font-size: 14px;
            color: #222;
            margin-bottom: 4px;
        }
        .game-hint {
            font-size: 12px;
            color: #666;
        }
        .toast {
            position: fixed;
            top: 20px; left: 50%;
            transform: translateX(-50%);
            background: rgba(0,0,0,0.75);
            color: #fff;
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 14px;
            z-index: 999999;
            opacity: 0;
            transition: opacity 0.3s;
        }
        .toast.show {
            opacity: 1;
        }
    `);

    // 轻提示
    function showToast(msg) {
        let t = document.createElement('div');
        t.className = 'toast';
        t.textContent = msg;
        document.body.appendChild(t);
        setTimeout(() => t.classList.add('show'), 10);
        setTimeout(() => {
            t.classList.remove('show');
            setTimeout(() => t.remove(), 300);
        }, 1800);
    }

    // ====================== 【修复】正确抓取游戏与夸克链接 ======================
    function getRealGameList() {
        const games = [];

        // 匹配 mikuclub 真实游戏卡片
        const items = document.querySelectorAll("div.item, div.col-md-3, div.col-sm-4, div.card, div.game-item");

        items.forEach(el => {
            // 抓标题
            const titleEl = el.querySelector("a.title, h4, strong, .title");
            if (!titleEl) return;

            const title = titleEl.innerText.trim().replace(/\s+/g, " ");

            // 抓所有夸克链接（支持跳转链接解析）
            const links = el.querySelectorAll("a[href*='quark'], a[href*='pan.quark.cn'], a[href*='go.html?url=']");
            let realQuarkUrl = null;

            links.forEach(a => {
                let href = a.href.trim();

                // 解析站内跳转链接 go.html?url=xxx
                if (href.includes("go.html?url=")) {
                    try {
                        const p = new URLSearchParams(href.split("?")[1]);
                        const target = p.get("url");
                        if (target && target.includes("quark")) {
                            realQuarkUrl = decodeURIComponent(target);
                        }
                    } catch (e) {}
                }

                // 直接夸克链接
                if (href.includes("pan.quark.cn")) {
                    realQuarkUrl = href;
                }
            });

            if (realQuarkUrl) {
                games.push({ title, url: realQuarkUrl });
            }
        });

        return games;
    }

    // 创建悬浮按钮
    const btn = document.createElement("div");
    btn.id = "miku-toggle";
    btn.innerText = "🎮";
    document.body.appendChild(btn);

    // 创建面板
    const panel = document.createElement("div");
    panel.id = "miku-game-box";
    document.body.appendChild(panel);

    // 点击按钮显示游戏列表
    btn.addEventListener("click", () => {
        const list = getRealGameList();
        panel.innerHTML = "";

        if (list.length === 0) {
            panel.innerHTML = "<div style='color:#f56c6c;padding:10px;text-align:center;'>未找到夸克资源</div>";
            panel.style.display = "block";
            return;
        }

        list.forEach((g, i) => {
            const item = document.createElement("div");
            item.className = "game-item";
            item.innerHTML = `
                <div class="game-title">${i+1}. ${g.title}</div>
                <div class="game-hint">点击 → 自动保存到夸克网盘</div>
            `;
            item.addEventListener("click", () => {
                if (processing.has(g.url)) {
                    showToast("已在处理，请勿重复点击");
                    return;
                }
                processing.add(g.url);
                setTimeout(() => processing.delete(g.url), PROCESS_LOCK_SECONDS * 1000);

                GM_openInTab(g.url, { active: false, insert: true });
                showToast("已后台打开，自动保存中");
            });
            panel.appendChild(item);
        });

        panel.style.display = panel.style.display === "block" ? "none" : "block";
    });

    // ====================== 夸克自动保存 ======================
    if (location.host.includes("pan.quark.cn")) {
        setTimeout(() => {
            const saveBtn = document.querySelector("button:contains('保存'), button:has(span:contains('保存'))")
                || document.querySelector("button[class*='save']");

            if (saveBtn) saveBtn.click();

            setTimeout(() => {
                const confirmBtn = document.querySelector(".modal-footer button:last-child")
                    || document.querySelector("button:contains('确定'), button:has(span:contains('确定'))");

                if (confirmBtn) confirmBtn.click();

                setTimeout(() => window.close(), 2000);
            }, 1500);
        }, 1500);
    }

})();