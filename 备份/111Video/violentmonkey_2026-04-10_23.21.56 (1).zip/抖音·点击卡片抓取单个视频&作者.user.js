// ==UserScript==
// @name         抖音·点击卡片抓取单个视频&作者
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  点击任意视频卡片，面板只显示这一个的视频链接+作者主页，不卡不批量
// @author       豆包
// @match        *://www.douyin.com/*
// @match        *://v.douyin.com/*
// @grant        GM_setClipboard
// @grant        GM_addStyle
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    // 面板样式
    GM_addStyle(`
        #dyCardInfo {
            position: fixed;
            top: 10px;
            left: 10px;
            width: 360px;
            background: #1a1a1a;
            color: #fff;
            border-radius: 10px;
            padding: 12px;
            z-index: 999999;
            box-shadow: 0 0 12px rgba(0,0,0,0.5);
            font-size: 12px;
            line-height: 1.5;
        }
        #dyCardInfo .title {
            font-weight: bold;
            color: #ff4e79;
            margin-bottom: 8px;
        }
        #dyCardInfo .item {
            margin: 6px 0;
        }
        #dyCardInfo .link {
            color: #ccc;
            word-break: break-all;
        }
        #dyCardInfo .copy {
            display: inline-block;
            background: #444;
            color: #fff;
            border-radius: 4px;
            padding: 2px 6px;
            cursor: pointer;
            font-size: 11px;
            margin-right: 4px;
        }
    `);

    // 创建面板
    const panel = document.createElement('div');
    panel.id = 'dyCardInfo';
    panel.innerHTML = `
        <div class="title">点击任意视频卡片查看</div>
        <div class="item">视频链接：<div class="link" id="v_url">-</div></div>
        <div class="item">作者主页：<div class="link" id="a_url">-</div></div>
        <div>
            <span class="copy" id="c_v">复制视频</span>
            <span class="copy" id="c_a">复制作者</span>
        </div>
    `;
    document.body.appendChild(panel);

    // 抓取单个卡片信息
    function grabCard(card) {
        // 视频链接
        const vNode = card.querySelector('a[href*="/video/"]');
        const video = vNode ? vNode.href.split('?')[0] : '未找到';

        // 作者链接
        const aNode = card.querySelector('a[href*="/user/"]');
        const author = aNode ? aNode.href.split('?')[0] : '未找到';

        // 显示到面板
        document.getElementById('v_url').innerText = video;
        document.getElementById('a_url').innerText = author;
    }

    // 监听点击：点哪个卡片，抓哪个
    document.addEventListener('click', function(e) {
        // 向上找最近的视频卡片
        const card = e.target.closest('[data-e2e="feed-card"], [data-e2e="video-card"], div[class*="video"], div[class*="card"]');
        if (card) grabCard(card);
    }, true);

    // 复制功能
    document.getElementById('c_v').onclick = () => {
        GM_setClipboard(document.getElementById('v_url').innerText);
    };
    document.getElementById('c_a').onclick = () => {
        GM_setClipboard(document.getElementById('a_url').innerText);
    };
})();