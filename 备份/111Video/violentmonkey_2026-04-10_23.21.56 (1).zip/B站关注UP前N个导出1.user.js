// ==UserScript==
// @name         B站关注UP前N个导出1
// @version      1.0
// @description  输入数字，导出最新关注的前N个UP主主页链接
// @author       豆包
// @match        https://space.bilibili.com/105501015/relation/follow
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // 创建面板
    const panel = document.createElement('div');
    panel.style.cssText = `
        position: fixed; top: 20px; right: 20px; z-index: 9999;
        background: #fff; border-radius: 8px; box-shadow: 0 2px 12px rgba(0,0,0,0.15);
        padding: 12px; display: flex; gap: 8px; align-items: center;
    `;

    // 输入框
    const input = document.createElement('input');
    input.type = 'number';
    input.placeholder = '导出前N个';
    input.value = '20';
    input.style.width = '80px';
    input.style.padding = '6px';

    // 按钮
    const btn = document.createElement('button');
    btn.textContent = '导出UP主页链接';
    btn.style.padding = '6px 12px';
    btn.style.backgroundColor = '#fb7299';
    btn.style.color = '#fff';
    btn.style.border = 'none';
    btn.style.borderRadius = '4px';
    btn.style.cursor = 'pointer';

    panel.append(input, btn);
    document.body.appendChild(panel);

    // 点击导出
    btn.onclick = async () => {
        const limit = parseInt(input.value) || 20;
        if (limit < 1) return alert('请输入大于0的数字');

        btn.disabled = true;
        btn.textContent = '获取中...';

        const myUID = location.pathname.split('/')[1];
        let upList = [];

        try {
            // 只请求第1页，取前N个（最新关注）
            const api = `https://api.bilibili.com/x/relation/followings?vmid=${myUID}&pn=1&ps=50`;
            const res = await fetch(api).then(r => r.json());

            if (res.code !== 0) throw new Error('获取失败');

            const list = res.data.list.slice(0, limit);
            upList = list.map(u => `https://space.bilibili.com/${u.mid}`);

            // 下载txt
            const blob = new Blob([upList.join('\n')], { type: 'text/plain' });
            const a = document.createElement('a');
            a.download = `B站关注前${upList.length}个UP.txt`;
            a.href = URL.createObjectURL(blob);
            a.click();

            btn.textContent = `成功导出 ${upList.length} 个`;
        } catch (e) {
            alert('出错：' + e.message);
            btn.textContent = '导出失败';
        } finally {
            setTimeout(() => {
                btn.disabled = false;
                btn.textContent = '导出UP主页链接';
            }, 1500);
        }
    };
})();