// ==UserScript==
// @name        New script - bilibili.com
// @namespace   Violentmonkey Scripts
// @match       https://www.bilibili.com/video/BV1Sy4y1C7ha
// @grant       none
// @version     1.0
// @author      -
// @description 2022/12/4 17:12:00
// ==/UserScript==
var search = document.querySelector('input');
document.addEventListener('keyup',function(e){
            if(e.KeyCode == 83){
                search.focus();
            }
        })