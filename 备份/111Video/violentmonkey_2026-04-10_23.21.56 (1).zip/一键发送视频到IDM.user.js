// ==UserScript==
// @name        一键发送视频到IDM
// @namespace   http://example.com/
// @match       *://*/*
// @grant       none
// @version     1.0
// @author      助手
// @description 网页右下角按钮，一键获取视频地址并发送到IDM
// ==/UserScript==

(function() {
    // 创建悬浮按钮
    const btn = document.createElement('button');
    btn.textContent = '发送到IDM';
    btn.style.position = 'fixed';
    btn.style.right = '20px';
    btn.style.bottom = '50px';
    btn.style.zIndex = '999999';
    btn.style.padding = '10px 14px';
    btn.style.background = '#0078d7';
    btn.style.color = '#fff';
    btn.style.border = 'none';
    btn.style.borderRadius = '6px';
    btn.style.cursor = 'pointer';
    document.body.appendChild(btn);

    // 点击事件
    btn.onclick = function() {
        const video = document.querySelector('video');
        if (!video) {
            alert('未找到视频');
            return;
        }
        const url = video.currentSrc || video.src;
        if (!url) {
            alert('未获取到视频地址');
            return;
        }
        // 调用IDM
        window.open(`idm://download?url=${encodeURIComponent(url)}`, '_blank');
    };
})();