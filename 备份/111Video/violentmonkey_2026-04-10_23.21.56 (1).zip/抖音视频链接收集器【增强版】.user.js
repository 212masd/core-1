// ==UserScript==
// @name         抖音视频链接收集器【增强版】
// @namespace    http://tampermonkey.net/
// @version      5.0
// @description  抖音搜索页采集前100条视频链接+序号+批量导入+可拖动+折叠+暂停+导出
// @author       helper
// @match        https://www.douyin.com/*
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    // 面板样式（纯黑不透明、红色细边框、适配所有功能）
    const css = `
        #videoPanel {
            position: fixed;
            top: 20px;
            left: 20px;
            width: 420px;
            background: #000 !important;
            color: #fff;
            border: 1px solid #ff0000;
            border-radius: 8px;
            z-index: 99999999;
            font-size: 12px;
            overflow: hidden;
            user-select: none;
        }
        #videoPanel .head {
            padding: 10px 12px;
            background: #111;
            cursor: move;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        #videoPanel .btns button {
            margin-left: 6px;
            padding: 3px 8px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            font-size: 11px;
        }
        #videoPanel .import-area {
            padding: 8px 12px;
            background: #1a1a1a;
            border-bottom: 1px solid #222;
            display: none;
        }
        #videoPanel.show .import-area {
            display: block;
        }
        #videoPanel .import-area textarea {
            width: 100%;
            height: 60px;
            background: #222;
            color: #fff;
            border: 1px solid #333;
            border-radius: 4px;
            padding: 6px;
            resize: none;
            margin-bottom: 6px;
            font-size: 12px;
        }
        #videoPanel .import-area .import-btn {
            background: #4caf50;
            color: #fff;
            border: none;
            padding: 4px 12px;
            border-radius: 4px;
            cursor: pointer;
        }
        #videoPanel .list {
            padding: 10px 12px;
            max-height: 50vh;
            overflow-y: auto;
            display: none;
        }
        #videoPanel.show .list {
            display: block;
        }
        #videoPanel .list::-webkit-scrollbar {
            width: 6px;
            background: #222;
        }
        #videoPanel .list::-webkit-scrollbar-thumb {
            background: #444;
            border-radius: 3px;
        }
        #videoPanel .item {
            padding: 5px 0;
            border-bottom: 1px solid #222;
            display: flex;
            align-items: flex-start;
        }
        #videoPanel .item .num {
            color: #ff0000;
            margin-right: 8px;
            font-weight: bold;
            min-width: 20px;
            text-align: center;
        }
        #videoPanel .item a {
            color: #38adff;
            word-break: break-all;
            flex: 1;
            text-decoration: none;
        }
        #videoPanel .item a:hover {
            text-decoration: underline;
        }
        #videoPanel .foot {
            padding: 8px 12px;
            background: #111;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        #videoPanel .foot button {
            padding: 4px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 11px;
        }
        #videoPanel .count {
            color: #999;
            font-size: 11px;
        }
    `;
    const style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);

    // 创建面板（新增批量导入区域、数量统计）
    const panel = document.createElement('div');
    panel.id = 'videoPanel';
    panel.innerHTML = `
        <div class="head" id="dragArea">
            <span>抖音链接收集器【增强版】</span>
            <div class="btns">
                <button id="btnToggle">展开</button>
                <button id="btnPause">采集</button>
            </div>
        </div>
        <div class="import-area">
            <textarea id="importText" placeholder="批量导入链接：粘贴多个链接，每行1个或用空格/回车分隔"></textarea>
            <button class="import-btn" id="btnImport">批量导入（自动去重）</button>
        </div>
        <div class="list" id="linkList"></div>
        <div class="foot">
            <span class="count" id="linkCount">当前采集：0条（最大100条）</span>
            <div>
                <button id="btnExport">导出TXT</button>
                <button id="btnClear">清空</button>
            </div>
        </div>
    `;
    document.body.appendChild(panel);

    // 元素获取
    const list = document.getElementById('linkList');
    const btnToggle = document.getElementById('btnToggle');
    const btnPause = document.getElementById('btnPause');
    const btnExport = document.getElementById('btnExport');
    const btnClear = document.getElementById('btnClear');
    const btnImport = document.getElementById('btnImport');
    const importText = document.getElementById('importText');
    const dragArea = document.getElementById('dragArea');
    const linkCount = document.getElementById('linkCount');

    // 核心状态（限制最大100条、采集开关、展开状态）
    let isShow = false;
    let isPause = false;
    const links = new Set(); // 自动去重
    const MAX_NUM = 100; // 最大采集100条

    // 1. 展开/折叠切换（同步显示导入区域和列表）
    btnToggle.addEventListener('click', () => {
        isShow = !isShow;
        panel.classList.toggle('show', isShow);
        btnToggle.textContent = isShow ? '折叠' : '展开';
    });

    // 2. 暂停/采集开关（红色=暂停，绿色=采集）
    btnPause.addEventListener('click', () => {
        isPause = !isPause;
        btnPause.textContent = isPause ? '已暂停' : '采集';
        btnPause.style.background = isPause ? '#f44336' : '#4caf50';
        // 暂停后更新计数
        updateCount();
    });
    btnPause.style.background = '#4caf50';

    // 3. 面板拖动功能（仅头部可拖，边界防溢出）
    (function dragPanel() {
        let mouseX, mouseY, panelX, panelY, dragging = false;
        dragArea.addEventListener('mousedown', e => {
            dragging = true;
            mouseX = e.clientX;
            mouseY = e.clientY;
            panelX = panel.offsetLeft;
            panelY = panel.offsetTop;
            dragArea.style.background = '#222';
            e.preventDefault();
        });
        document.addEventListener('mousemove', e => {
            if (!dragging) return;
            const dx = e.clientX - mouseX;
            const dy = e.clientY - mouseY;
            // 边界限制：不超出浏览器可视区域
            let newX = panelX + dx;
            let newY = panelY + dy;
            newX = Math.max(0, Math.min(newX, window.innerWidth - panel.offsetWidth));
            newY = Math.max(0, Math.min(newY, window.innerHeight - panel.offsetHeight));
            panel.style.left = newX + 'px';
            panel.style.top = newY + 'px';
        });
        document.addEventListener('mouseup', () => {
            dragging = false;
            dragArea.style.background = '#111';
        });
    })();

    // 4. 核心：采集搜索页视频链接（最多100条、带序号、自动滚动加载）
    function collectLinks() {
        // 暂停/达到100条时停止采集
        if (isPause || links.size >= MAX_NUM) {
            if (links.size >= MAX_NUM) btnPause.textContent = '已达100条';
            return;
        }
        // 仅在抖音搜索页执行采集（匹配搜索结果URL）
        if (!window.location.href.includes('/search/')) return;
        // 抓取所有视频链接（适配抖音搜索页视频a标签）
        document.querySelectorAll('a[href*="/video/"]').forEach(a => {
            if (links.size >= MAX_NUM) return;
            const url = a.href.trim().replace(/\?.*/, ''); // 去除链接后缀参数，避免重复
            // 过滤无效链接和非抖音视频链接
            if (!url.includes('douyin.com/video/') || links.has(url)) return;
            links.add(url);
        });
        // 采集后渲染列表（带序号）
        renderList();
        // 抖音搜索页自动滚动加载下一页（模拟人工滚动，触发更多视频加载）
        if (links.size < MAX_NUM && !isPause) {
            window.scrollBy(0, 500);
        }
    }

    // 5. 渲染链接列表（前缀序号、按采集顺序排列）
    function renderList() {
        list.innerHTML = '';
        // 按采集顺序转换为数组，添加序号
        const linkArray = Array.from(links);
        linkArray.forEach((url, index) => {
            const div = document.createElement('div');
            div.className = 'item';
            // 序号从1开始，红色显示
            div.innerHTML = `
                <span class="num">${index + 1}</span>
                <a href="${url}" target="_blank">${url}</a>
            `;
            list.appendChild(div);
        });
        // 更新数量统计
        updateCount();
    }

    // 6. 更新采集数量统计
    function updateCount() {
        linkCount.textContent = `当前采集：${links.size}条（最大${MAX_NUM}条）`;
    }

    // 7. 新增：批量导入链接（支持回车/空格/换行分隔，自动去重/过滤无效）
    btnImport.addEventListener('click', () => {
        if (!importText.value.trim()) {
            alert('请粘贴需要导入的链接！');
            return;
        }
        // 分割链接：支持回车、空格、制表符、逗号分隔
        const importLinks = importText.value.trim().split(/[\n\s,;]+/).filter(link => link);
        let successNum = 0;
        importLinks.forEach(link => {
            // 过滤无效链接，仅保留抖音视频链接，自动去重，不超100条
            if (links.size >= MAX_NUM) return;
            const pureLink = link.replace(/\?.*/, '');
            if (pureLink.includes('douyin.com/video/') && !links.has(pureLink)) {
                links.add(pureLink);
                successNum++;
            }
        });
        // 渲染列表+清空输入框+提示
        renderList();
        importText.value = '';
        alert(`批量导入完成！成功导入${successNum}条，过滤无效/重复${importLinks.length - successNum}条`);
    });

    // 8. 导出TXT（带序号，与面板显示一致）
    btnExport.addEventListener('click', () => {
        if (links.size === 0) {
            alert('暂无链接可导出！');
            return;
        }
        // 导出内容带序号，与面板一致
        const linkArray = Array.from(links);
        let exportText = '';
        linkArray.forEach((url, index) => {
            exportText += `${index + 1}. ${url}\n`;
        });
        // 生成TXT文件下载
        const blob = new Blob([exportText], { type: 'text/plain; charset=utf-8' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `抖音视频链接_${links.size}条.txt`;
        a.click();
        // 释放blob资源
        URL.revokeObjectURL(a.href);
    });

    // 9. 清空列表（确认弹窗，防止误操作）
    btnClear.addEventListener('click', () => {
        if (!confirm(`确定清空所有${links.size}条链接吗？`)) return;
        links.clear();
        renderList();
        btnPause.textContent = '采集';
        btnPause.style.background = '#4caf50';
    });

    // 10. 采集定时器+滚动触发（适配抖音懒加载，精准采集）
    // 初始延迟采集（等待页面加载完成）
    setTimeout(() => {
        collectLinks();
        // 定时采集（每800ms一次，适配抖音加载速度）
        setInterval(collectLinks, 800);
    }, 1500);
    // 滚动页面再次触发采集（防止漏采）
    window.addEventListener('scroll', () => {
        if (!isPause && links.size < MAX_NUM) setTimeout(collectLinks, 300);
    });

})();