// ==UserScript==
// @name         抖音强制可见·视频左上角复制作者+批量导出
// @namespace    http://tampermonkey.net/
// @version      2026.3
// @description  强制可见、无视抖音遮蔽、可拖动面板、批量选择导出作者主页
// @author       helper
// @match        *://www.douyin.com/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    // ==============================================
    // 全局样式注入：强制让脚本元素永远可见、可点击
    // ==============================================
    const style = document.createElement('style');
    style.textContent = `
        /* 强制面板永远可见 */
        #authorPanelWrapper,
        #authorPanelWrapper * {
            display: block !important;
            opacity: 1 !important;
            visibility: visible !important;
            pointer-events: auto !important;
            z-index: 999999999 !important;
            position: fixed !important;
            background: #1a1a1a !important;
            color: #fff !important;
        }

        /* 强制视频卡片上的按钮可见 */
        .author-copy-btn {
            display: inline-flex !important;
            opacity: 1 !important;
            visibility: visible !important;
            z-index: 9999999 !important;
            position: absolute !important;
            background: #fe2c55 !important;
            color: #fff !important;
            padding: 4px 10px !important;
            border-radius: 8px !important;
            font-size: 12px !important;
            font-weight: bold !important;
            cursor: pointer !important;
            user-select: none !important;
        }
    `;
    document.documentElement.appendChild(style);

    // ==============================================
    // 全局状态
    // ==============================================
    const authorSet = new Map();
    let panel, listContainer, btnSelectAll, btnExport;
    let isSelectAll = false;

    // ==============================================
    // 创建顶部控制面板（强制可见）
    // ==============================================
    function createPanel() {
        panel = document.createElement('div');
        panel.id = 'authorPanelWrapper';
        panel.style.cssText = `
            top: 10px;
            left: 20px;
            width: 360px;
            max-height: 70vh;
            padding: 12px;
            border-radius: 12px;
            box-shadow: 0 0 20px rgba(0,0,0,0.8);
            overflow-y: auto;
        `;

        // 标题栏（可拖动）
        const head = document.createElement('div');
        head.style.cssText = `
            position: relative !important;
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 10px;
            cursor: move;
            padding: 4px 0;
        `;
        head.textContent = '作者批量导出';
        panel.appendChild(head);

        // 按钮栏
        const bar = document.createElement('div');
        bar.style.cssText = `
            position: relative !important;
            display: flex;
            gap: 8px;
            margin-bottom: 12px;
        `;

        btnSelectAll = document.createElement('button');
        btnSelectAll.textContent = '全选';
        btnSelectAll.style.cssText = `
            flex: 1;
            padding: 6px;
            background: #333 !important;
            border: none;
            border-radius: 6px;
            color: #fff;
            cursor: pointer;
        `;

        btnExport = document.createElement('button');
        btnExport.textContent = '批量复制选中';
        btnExport.style.cssText = `
            flex: 2;
            padding: 6px;
            background: #fe2c55 !important;
            border: none;
            border-radius: 6px;
            color: #fff;
            cursor: pointer;
        `;

        bar.append(btnSelectAll, btnExport);
        panel.appendChild(bar);

        // 作者列表容器
        listContainer = document.createElement('div');
        listContainer.style.cssText = `
            position: relative !important;
            display: flex;
            flex-direction: column;
            gap: 6px;
        `;
        panel.appendChild(listContainer);

        document.body.appendChild(panel);

        // 拖动逻辑
        let dragging = false, startX, startY, lastLeft, lastTop;
        head.addEventListener('mousedown', e => {
            dragging = true;
            startX = e.clientX;
            startY = e.clientY;
            lastLeft = parseInt(panel.style.left) || 20;
            lastTop = parseInt(panel.style.top) || 10;
        });
        document.addEventListener('mousemove', e => {
            if (!dragging) return;
            panel.style.left = lastLeft + (e.clientX - startX) + 'px';
            panel.style.top = lastTop + (e.clientY - startY) + 'px';
        });
        document.addEventListener('mouseup', () => dragging = false);
    }

    // ==============================================
    // 添加作者到列表（自动去重）
    // ==============================================
    function addAuthor(url, nickname) {
        if (authorSet.has(url)) return;
        authorSet.set(url, nickname);

        const item = document.createElement('label');
        item.style.cssText = `
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 6px 8px;
            background: #282828;
            border-radius: 6px;
            font-size: 13px;
        `;

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.value = url;

        const name = document.createElement('span');
        name.textContent = nickname || url.split('/').pop();

        item.append(checkbox, name);
        listContainer.appendChild(item);
    }

    // ==============================================
    // 全选 / 取消全选
    // ==============================================
    btnSelectAll?.addEventListener('click', () => {
        isSelectAll = !isSelectAll;
        btnSelectAll.textContent = isSelectAll ? '取消全选' : '全选';
        listContainer.querySelectorAll('input').forEach(cb => {
            cb.checked = isSelectAll;
        });
    });

    // ==============================================
    // 批量复制选中作者
    // ==============================================
    btnExport?.addEventListener('click', () => {
        const selected = [];
        listContainer.querySelectorAll('input:checked').forEach(cb => {
            selected.push(cb.value);
        });
        if (selected.length === 0) {
            btnExport.textContent = '未选择';
            setTimeout(() => btnExport.textContent = '批量复制选中', 1000);
            return;
        }
        navigator.clipboard.writeText(selected.join('\n')).then(() => {
            btnExport.textContent = `已复制 ${selected.length} 个`;
            setTimeout(() => btnExport.textContent = '批量复制选中', 1200);
        });
    });

    // ==============================================
    // 给单个视频添加按钮
    // ==============================================
    function addButton(card) {
        if (card.hasAttribute('author-btn-added')) return;
        card.setAttribute('author-btn-added', 'true');

        // 强制父级相对定位
        card.style.position = 'relative';

        const btn = document.createElement('div');
        btn.className = 'author-copy-btn';
        btn.textContent = '复制作者';

        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            e.preventDefault();

            const a = card.querySelector('a[href*="/user/"], a[href^="/@"]');
            if (!a) {
                btn.textContent = '失败';
                setTimeout(() => btn.textContent = '复制作者', 1000);
                return;
            }

            const fullUrl = new URL(a.getAttribute('href'), 'https://www.douyin.com').href;
            const nickname = a.textContent.trim() || '';

            navigator.clipboard.writeText(fullUrl).then(() => {
                btn.textContent = '已复制';
                setTimeout(() => btn.textContent = '复制作者', 1000);
                addAuthor(fullUrl, nickname);
            });
        });

        card.appendChild(btn);
    }

    // ==============================================
    // 扫描所有视频
    // ==============================================
    function scanVideos() {
        const cards = [];
        // 2026.3 抖音真实视频卡片匹配
        cards.push(...document.querySelectorAll('div[data-e2e="video-card"]'));
        cards.push(...document.querySelectorAll('div[data-e2e="feed-card"]'));
        cards.push(...document.querySelectorAll('div[role="button"][tabindex="-1"]'));
        cards.forEach(addButton);
    }

    // ==============================================
    // 启动
    // ==============================================
    window.addEventListener('DOMContentLoaded', () => {
        createPanel();
        scanVideos();

        // 监听无限滚动
        const observer = new MutationObserver(scanVideos);
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    });

})();