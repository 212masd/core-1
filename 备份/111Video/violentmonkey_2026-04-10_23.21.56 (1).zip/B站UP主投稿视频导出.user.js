// ==UserScript==
// @name         B站UP主投稿视频导出
// @namespace    http://tampermonkey.net/
// @version      1.01
// @description  在B站UP主个人空间“投稿-视频”页面增加下拉菜单导出按钮，自动翻页抓取所有视频数据，支持CSV/JSON/HTML。
// @author       AI Assistant
// @match        *://space.bilibili.com/*
// @icon         https://www.bilibili.com/favicon.ico
// @grant        none
// @downloadURL https://update.greasyfork.org/scripts/572959/B%E7%AB%99UP%E4%B8%BB%E6%8A%95%E7%A8%BF%E8%A7%86%E9%A2%91%E5%AF%BC%E5%87%BA.user.js
// @updateURL https://update.greasyfork.org/scripts/572959/B%E7%AB%99UP%E4%B8%BB%E6%8A%95%E7%A8%BF%E8%A7%86%E9%A2%91%E5%AF%BC%E5%87%BA.meta.js
// ==/UserScript==

(function() {
    'use strict';

    let isExporting = false;
    let videoDataList = [];
    let bvidSet = new Set();

    // 注入自定义 CSS 样式
    const style = document.createElement('style');
    style.innerHTML = `
        .my-export-container { position: relative; display: inline-block; margin-left: 12px; vertical-align: middle; z-index: 999; }
        .my-export-btn { background-color: #00aeec; color: #fff; display: flex; align-items: center; justify-content: center; cursor: pointer; border-radius: 6px; padding: 0 16px; height: 32px; font-size: 14px; border: none; transition: background-color 0.3s; font-family: inherit;}
        .my-export-btn:hover { background-color: #40c5f1; }
        .my-export-menu { position: absolute; top: 100%; left: 50%; transform: translateX(-50%); background: #fff; border: 1px solid #e3e5e7; border-radius: 8px; box-shadow: 0 2px 12px rgba(0,0,0,0.1); display: none; flex-direction: column; min-width: 130px; overflow: hidden; padding: 6px 0; }
        .my-export-container:hover .my-export-menu { display: flex; }
        .my-export-item { padding: 10px 16px; font-size: 14px; color: #18191c; cursor: pointer; text-align: center; transition: background 0.2s, color 0.2s; white-space: nowrap; }
        .my-export-item:hover { background: #f6f7f8; color: #00aeec; }
        .my-export-disabled { pointer-events: none; opacity: 0.8; }
        .my-export-disabled .my-export-menu { display: none !important; }
    `;
    document.head.appendChild(style);

    // 监听DOM变化，动态插入导出按钮组
    const initInterval = setInterval(() => {
        if (!location.href.includes('/video') && !document.querySelector('.bili-video-card')) {
            return;
        }

        const headerTop = document.querySelector('.video-header__top');
        const existingContainer = document.querySelector('#my-export-container');

        if (headerTop && !existingContainer) {
            const container = document.createElement('div');
            container.id = 'my-export-container';
            container.className = 'my-export-container';

            // 主按钮
            const mainBtn = document.createElement('button');
            mainBtn.className = 'my-export-btn';
            mainBtn.innerHTML = '<span class="btn-text">📥 导出数据</span><span style="font-size:10px; margin-left:6px;">▼</span>';

            // 下拉菜单
            const menu = document.createElement('div');
            menu.className = 'my-export-menu';

            const formats = ['CSV', 'JSON', 'HTML'];
            formats.forEach(format => {
                const item = document.createElement('div');
                item.className = 'my-export-item';
                item.innerText = `导出为 ${format}`;
                item.onclick = async (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    if (isExporting) return;

                    // 设置为正在导出状态
                    container.classList.add('my-export-disabled');
                    mainBtn.style.backgroundColor = '#fb7299';

                    await startScraping(format, mainBtn, container);
                };
                menu.appendChild(item);
            });

            container.appendChild(mainBtn);
            container.appendChild(menu);
            headerTop.appendChild(container);
        }
    }, 1500);

    // 核心抓取与翻页逻辑
    async function startScraping(format, mainBtn, container) {
        isExporting = true;
        videoDataList = [];
        bvidSet.clear();
        const textSpan = mainBtn.querySelector('.btn-text');

        try {
            // 如果不在第一页，尝试回到第一页
            const pageOneBtn = document.querySelector('.vui_pagenation--btn-num');
            if (pageOneBtn && pageOneBtn.innerText === '1' && !pageOneBtn.classList.contains('vui_button--active')) {
                pageOneBtn.click();
                await sleep(2500);
            }

            let hasNextPage = true;
            let pageCount = 1;

            while (hasNextPage && isExporting) {
                textSpan.innerText = `正在扫描第 ${pageCount} 页...`;
                await sleep(2500); // 等待页面加载和渲染

                const cards = document.querySelectorAll('.bili-video-card');
                cards.forEach(card => {
                    try {
                        const titleEl = card.querySelector('.bili-video-card__title a');
                        if (!titleEl) return;

                        let title = titleEl.innerText || titleEl.getAttribute('title') || '';
                        title = title.replace(/"/g, '""').replace(/[\r\n]/g, ' '); // 净化标题

                        // 提取URL并去除冗余参数
                        let rawLink = titleEl.href || '';
                        let bvidMatch = rawLink.match(/video\/(BV[a-zA-Z0-9]+)/);
                        let bvid = bvidMatch ? bvidMatch[1] : '';

                        // 生成纯净版链接
                        let cleanLink = bvid ? `https://www.bilibili.com/video/${bvid}/` : rawLink.split('?')[0];

                        // 去重
                        if (bvid && bvidSet.has(bvid)) return;
                        bvidSet.add(bvid);

                        const stats = card.querySelectorAll('.bili-cover-card__stat span');
                        const playCount = stats[0] ? stats[0].innerText : '0';
                        const danmakuCount = stats[1] ? stats[1].innerText : '0';
                        const duration = stats[2] ? stats[2].innerText : '00:00';

                        const dateEl = card.querySelector('.bili-video-card__subtitle span');
                        const pubDate = dateEl ? dateEl.innerText : '';

                        videoDataList.push({
                            title, bvid, playCount, danmakuCount, duration, pubDate, link: cleanLink
                        });
                    } catch (err) {
                        console.error('抓取单条出错', err);
                    }
                });

                const pageBtns = document.querySelectorAll('.vui_pagenation--btn-side');
                let nextBtn = Array.from(pageBtns).find(el => el.innerText.includes('下一页'));

                if (nextBtn && !nextBtn.disabled && !nextBtn.classList.contains('vui_button--disabled')) {
                    nextBtn.click();
                    pageCount++;
                } else {
                    hasNextPage = false;
                }
            }

            const upNameEl = document.querySelector('.upinfo-detail__top .nickname');
            const upName = upNameEl ? upNameEl.innerText.trim() : 'UP主';

            // 根据选择的格式生成文件
            if (format === 'CSV') exportCSV(videoDataList, upName);
            if (format === 'JSON') exportJSON(videoDataList, upName);
            if (format === 'HTML') exportHTML(videoDataList, upName);

            textSpan.innerText = `✅ 成功导出 ${videoDataList.length} 条`;

        } catch (err) {
            alert('导出出错：' + err.message);
            textSpan.innerText = `❌ 导出失败`;
        } finally {
            // 恢复按钮状态
            setTimeout(() => {
                isExporting = false;
                mainBtn.style.backgroundColor = '#00aeec';
                textSpan.innerText = '📥 导出数据';
                container.classList.remove('my-export-disabled');
            }, 3000);
        }
    }

    // ---------------- 导出各格式的具体实现 ----------------

    function exportCSV(dataArray, upName) {
        let csvContent = '\uFEFF标题,BV号,播放量,弹幕数,时长,发布时间,视频链接\n';
        dataArray.forEach(row => {
            csvContent += `"${row.title}",${row.bvid},${row.playCount},${row.danmakuCount},${row.duration},${row.pubDate},${row.link}\n`;
        });
        downloadFile(csvContent, 'text/csv', `${upName}_视频数据_${getTimeStr()}.csv`);
    }

    function exportJSON(dataArray, upName) {
        const jsonContent = JSON.stringify(dataArray, null, 4);
        downloadFile(jsonContent, 'application/json', `${upName}_视频数据_${getTimeStr()}.json`);
    }

    function exportHTML(dataArray, upName) {
        let rows = dataArray.map(r => `
            <tr>
                <td>${r.title}</td>
                <td>${r.bvid}</td>
                <td>${r.playCount}</td>
                <td>${r.danmakuCount}</td>
                <td>${r.duration}</td>
                <td>${r.pubDate}</td>
                <td><a href="${r.link}" target="_blank">点击观看</a></td>
            </tr>`).join('');

        let htmlContent = `
        <!DOCTYPE html>
        <html lang="zh-CN">
        <head>
            <meta charset="UTF-8">
            <title>${upName} 的投稿视频数据</title>
            <style>
                body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; margin: 30px; background: #f6f7f8; color: #333;}
                h1 { text-align: center; color: #fb7299; }
                .stats { text-align: center; margin-bottom: 20px; font-size: 16px; color: #666; }
                table { width: 100%; border-collapse: collapse; background: #fff; box-shadow: 0 2px 8px rgba(0,0,0,0.08); border-radius: 8px; overflow: hidden; }
                th, td { border: 1px solid #e3e5e7; padding: 12px 15px; text-align: center; }
                th { background-color: #00aeec; color: #fff; font-weight: 500; position: sticky; top: 0; }
                td:nth-child(1) { text-align: left; max-width: 300px; }
                tr:nth-child(even) { background-color: #f1f2f3; }
                tr:hover { background-color: #e3e5e7; }
                a { color: #00aeec; text-decoration: none; font-weight: 500; }
                a:hover { color: #fb7299; text-decoration: underline; }
            </style>
        </head>
        <body>
            <h1>${upName} 的投稿视频数据</h1>
            <div class="stats">共收录 ${dataArray.length} 个视频 ｜ 导出时间：${new Date().toLocaleString()}</div>
            <table>
                <thead>
                    <tr>
                        <th>视频标题</th><th>BV号</th><th>播放量</th><th>弹幕数</th><th>时长</th><th>发布时间</th><th>视频链接</th>
                    </tr>
                </thead>
                <tbody>${rows}</tbody>
            </table>
        </body>
        </html>`;

        downloadFile(htmlContent, 'text/html', `${upName}_视频数据_${getTimeStr()}.html`);
    }

    // 通用底层下载逻辑 (绕过B站路由拦截)
    function downloadFile(content, mimeType, filename) {
        const blob = new Blob([content], { type: `${mimeType};charset=utf-8;` });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = filename;

        const clickEvent = new MouseEvent("click", {
            bubbles: false,
            cancelable: false,
            view: window
        });
        a.dispatchEvent(clickEvent);

        setTimeout(() => URL.revokeObjectURL(url), 5000);
    }

    function getTimeStr() {
        const now = new Date();
        return `${now.getFullYear()}${String(now.getMonth()+1).padStart(2,'0')}${String(now.getDate()).padStart(2,'0')}`;
    }

    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
})();