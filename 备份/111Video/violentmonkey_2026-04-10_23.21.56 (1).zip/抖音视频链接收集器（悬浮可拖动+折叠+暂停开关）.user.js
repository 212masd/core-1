// ==UserScript==
// @name         抖音视频链接收集器（悬浮可拖动+折叠+暂停开关）
// @namespace    http://tampermonkey.net/
// @version      3.0
// @description  自动收集抖音视频链接，右上角悬浮、可拖动、可折叠、可暂停、批量导出TXT
// @author       helper
// @match        https://www.douyin.com/*
// @match        https://www.douyin.com/web/*
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    // 样式
    const style = document.createElement('style');
    style.textContent = `
        #linkPanel {
            position: fixed;
            top: 20px;
            right: 20px;
            width: 360px;
            background: #1a1a1a;
            color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.5);
            z-index: 9999999;
            font-size: 12px;
            user-select: none;
            overflow: hidden;
        }
        #linkPanel .header {
            padding: 10px 12px;
            background: #2a2a2a;
            cursor: move;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        #linkPanel .title {
            font-weight: bold;
        }
        #linkPanel .btns {
            display: flex;
            gap: 6px;
        }
        #linkPanel .btns button {
            padding: 3px 6px;
            font-size: 11px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        #linkPanel .body {
            padding: 10px 12px;
            max-height: 65vh;
            overflow-y: auto;
            display: none;
        }
        #linkPanel.expanded .body {
            display: block;
        }
        #linkPanel .item {
            padding: 4px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        #linkPanel .item a {
            color: #60a9ff;
            text-overflow: ellipsis;
            overflow: hidden;
            white-space: nowrap;
            flex: 1;
        }
        #linkPanel .copyBtn {
            padding: 2px 6px;
            font-size: 10px;
            background: #333;
            color: #fff;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        #linkPanel .copyBtn:hover {
            background: #444;
        }
        #linkPanel .footer {
            padding: 8px 12px;
            background: #222;
            display: flex;
            justify-content: space-between;
        }
        #linkPanel .footer button {
            padding: 4px 8px;
            font-size: 11px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
    `;
    document.head.appendChild(style);

    // 面板结构
    const panel = document.createElement('div');
    panel.id = 'linkPanel';
    panel.innerHTML = `
        <div class="header" id="dragHandle">
            <div class="title">视频链接收集</div>
            <div class="btns">
                <button id="toggleBtn">折叠</button>
                <button id="pauseBtn">暂停</button>
            </div>
        </div>
        <div class="body" id="listBody"></div>
        <div class="footer">
            <button id="exportBtn">导出TXT</button>
            <button id="clearBtn">清空列表</button>
        </div>
    `;
    document.body.appendChild(panel);

    const listBody = document.getElementById('listBody');
    const toggleBtn = document.getElementById('toggleBtn');
    const pauseBtn = document.getElementById('pauseBtn');
    const exportBtn = document.getElementById('exportBtn');
    const clearBtn = document.getElementById('clearBtn');
    const dragHandle = document.getElementById('dragHandle');

    // 状态
    let isPaused = false;
    let isExpanded = true;
    let linkSet = new Set();

    // 折叠切换
    toggleBtn.addEventListener('click', () => {
        isExpanded = !isExpanded;
        panel.classList.toggle('expanded', isExpanded);
        toggleBtn.textContent = isExpanded ? '折叠' : '展开';
    });
    panel.classList.add('expanded');

    // 暂停开关
    pauseBtn.addEventListener('click', () => {
        isPaused = !isPaused;
        pauseBtn.textContent = isPaused ? '已暂停' : '收集';
        pauseBtn.style.background = isPaused ? '#ff4444' : '#4CAF50';
    });
    pauseBtn.style.background = '#4CAF50';

    // 拖动
    makeDraggable(panel, dragHandle);
    function makeDraggable(el, handle) {
        let pos = { x: 0, y: 0, cx: 0, cy: 0 };
        handle.style.cursor = 'move';
        handle.addEventListener('mousedown', start);

        function start(e) {
            e.preventDefault();
            pos.cx = e.clientX;
            pos.cy = e.clientY;
            document.addEventListener('mousemove', drag);
            document.addEventListener('mouseup', stop);
        }
        function drag(e) {
            pos.x = pos.cx - e.clientX;
            pos.y = pos.cy - e.clientY;
            pos.cx = e.clientX;
            pos.cy = e.clientY;
            el.style.top = (el.offsetTop - pos.y) + 'px';
            el.style.right = 'auto';
            el.style.left = (el.offsetLeft - pos.x) + 'px';
        }
        function stop() {
            document.removeEventListener('mousemove', drag);
            document.removeEventListener('mouseup', stop);
        }
    }

    // 收集链接
    function collect() {
        if (isPaused) return;
        document.querySelectorAll('a[href*="/video/"]').forEach(a => {
            const url = a.href.trim();
            if (!url.includes('/video/')) return;
            if (linkSet.has(url)) return;
            linkSet.add(url);

            const item = document.createElement('div');
            item.className = 'item';
            item.innerHTML = `
                <a href="${url}" target="_blank">${url}</a>
                <button class="copyBtn">复制</button>
            `;
            listBody.appendChild(item);

            item.querySelector('.copyBtn').addEventListener('click', () => {
                navigator.clipboard.writeText(url).then(() => {
                    alert('已复制：' + url);
                });
            });
        });
    }

    // 滚动 + 定时扫描
    let timer;
    window.addEventListener('scroll', () => {
        clearTimeout(timer);
        timer = setTimeout(collect, 300);
    });
    setInterval(collect, 2000);
    setTimeout(collect, 800);

    // 导出
    exportBtn.addEventListener('click', () => {
        const text = Array.from(linkSet).join('\n');
        const blob = new Blob([text], { type: 'text/plain' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'douyin_videos.txt';
        a.click();
    });

    // 清空
    clearBtn.addEventListener('click', () => {
        if (!confirm('确定清空？')) return;
        linkSet.clear();
        listBody.innerHTML = '';
    });

})();