// ==UserScript==
// @name         批量后台打开页面视频1
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  悬浮按钮点击，后台新标签打开当前页所有视频，适配B站等视频平台
// @author       自定义
// @match        *://*/*
// @grant        window.open
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    // 1. 创建悬浮按钮元素
    const btn = document.createElement('button');
    btn.innerText = '批量开视频';
    // 按钮样式：悬浮固定、醒目、不遮挡内容
    Object.assign(btn.style, {
        position: 'fixed',
        right: '20px',
        bottom: '20px',
        zIndex: '999999', // 最高层级，避免被遮挡
        padding: '10px 15px',
        background: '#fb7299', // B站粉，可自定义
        color: '#fff',
        border: 'none',
        borderRadius: '8px',
        fontSize: '14px',
        cursor: 'pointer',
        boxShadow: '0 2px 10px rgba(0,0,0,0.2)',
        opacity: '0.9',
        transition: 'opacity 0.2s'
    });
    // 鼠标悬停效果
    btn.onmouseover = () => { btn.style.opacity = '1'; };
    btn.onmouseout = () => { btn.style.opacity = '0.9'; };
    // 把按钮添加到页面
    document.body.appendChild(btn);

    // 2. 核心函数：提取视频链接并后台打开
    const openAllVideos = () => {
        // 定义视频链接选择器（**重点**：可根据目标网站修改）
        // B站搜索页/列表页视频链接选择器：a[href^="/video/"] （匹配以/video/开头的a标签）
        const videoLinks = document.querySelectorAll('a[href^="/video/"], a[href^="/bvid/"]');
        if (videoLinks.length === 0) {
            alert('当前页面未找到视频链接！');
            return;
        }

        // 去重链接（避免同一视频多次打开）
        const uniqueLinks = new Set();
        videoLinks.forEach(link => {
            // 拼接完整URL（处理相对路径）
            const fullUrl = new URL(link.href, window.location.origin).href;
            uniqueLinks.add(fullUrl);
        });

        // 批量后台打开：window.open(链接, '_blank') 实现后台新标签
        uniqueLinks.forEach(url => {
            window.open(url, '_blank');
        });

        alert(`成功找到${uniqueLinks.size}个视频，已后台新标签打开！`);
    };

    // 3. 绑定按钮点击事件
    btn.addEventListener('click', openAllVideos);

})();