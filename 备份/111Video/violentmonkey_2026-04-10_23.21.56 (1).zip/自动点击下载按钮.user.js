// ==UserScript==
// @name         自动点击下载按钮
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  页面加载完10秒后自动点击指定按钮
// @author       You
// @match        替换成你的目标网页URL（比如 https://xxx.com/*）
// @match        *://*.91porn.com/view_video.php*
// @match        *://*.91porn.com/index.php*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // ********** 仅需修改这2处 **********
    const DELAY_SECOND = 2000; // 延时10秒（固定值，不用改）
    const BUTTON_TEXT = '⬇️ 下载视频'; // 替换成你要点击的按钮上的文字

    // 找到目标按钮（按文字匹配）
    function findButton() {
        const allBtns = document.querySelectorAll('button, a');
        for (let btn of allBtns) {
            if (btn.textContent.includes(BUTTON_TEXT)) {
                return btn;
            }
        }
        return null;
    }

    // 页面加载完成后执行
    window.addEventListener('load', () => {
        // 延时10秒自动点击
        setTimeout(() => {
            const targetBtn = findButton();
            if (targetBtn) {
                targetBtn.click(); // 核心：自动点击按钮
                console.log('已自动点击按钮！');
            } else {
                alert('未找到按钮，请检查按钮文字是否正确！');
            }
        }, DELAY_SECOND);
    });
})();