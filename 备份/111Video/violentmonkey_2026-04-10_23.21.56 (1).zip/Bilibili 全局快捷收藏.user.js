// ==UserScript==
// @name         Bilibili 全局快捷收藏
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  仓鼠症患者必备
// @author       KobeBryant1145
// @match        *://*.bilibili.com/*
// @grant        GM_xmlhttpRequest
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_registerMenuCommand
// @connect      api.bilibili.com
// @license      MIT
// @downloadURL https://update.greasyfork.org/scripts/572803/Bilibili%20%E5%85%A8%E5%B1%80%E5%BF%AB%E6%8D%B7%E6%94%B6%E8%97%8F.user.js
// @updateURL https://update.greasyfork.org/scripts/572803/Bilibili%20%E5%85%A8%E5%B1%80%E5%BF%AB%E6%8D%B7%E6%94%B6%E8%97%8F.meta.js
// ==/UserScript==

(function() {
    'use strict';

    let isProcessing = false;
    let mouseX = 0;
    let mouseY = 0;

    const VIDEO_ID_REGEX = /(?:video\/|bvid=)(BV[a-zA-Z0-9]+|av\d+)/i;

    function getCookie(name) {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        if (parts.length === 2) return parts.pop().split(';').shift();
        return null;
    }

    GM_registerMenuCommand("⚙️ 更改一键收藏夹", openSettings);

    window.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
    });

    window.addEventListener('keydown', (e) => {
        if (e.key.toLowerCase() !== '\\') return;

        const tagName = e.target.tagName?.toLowerCase();
        const isInput = tagName === 'input' || tagName === 'textarea' || e.target.isContentEditable;
        if (isInput || isProcessing) return;

        let elementsUnderMouse =[];
        let currentRoot = document;
        let depth = 0;

        while (currentRoot && depth < 10) {
            let els = currentRoot.elementsFromPoint ? currentRoot.elementsFromPoint(mouseX, mouseY) :[];
            if (!els || els.length === 0) break;

            elementsUnderMouse.push(...els);

            let nextRoot = null;
            for (let el of els) {
                if (el.shadowRoot) {
                    nextRoot = el.shadowRoot;
                    console.log("[Bili快捷收藏] Found Shadow DOM:", el);
                    break;
                }
            }
            currentRoot = nextRoot;
            depth++;
        }

        let targetVid = null;

        for (let el of elementsUnderMouse) {
            const targetA = (el.tagName === 'A') ? el : (el.closest ? el.closest('a') : null);
            if (targetA && targetA.href) {
                const match = targetA.href.match(VIDEO_ID_REGEX);
                if (match) {
                    targetVid = match[1];
                    console.log("[Bili快捷收藏] hit target link", targetVid);
                    break;
                }
            }
        }

        if (!targetVid) {
            for (let el of elementsUnderMouse) {
                if (el.tagName && el.tagName !== 'BODY' && el.tagName !== 'HTML') {
                    const rect = el.getBoundingClientRect();
                    if (rect.width > 0 && rect.width < 800 && rect.height > 0 && rect.height < 600) {
                        const innerLinks = el.querySelectorAll('a[href*="/video/BV"], a[href*="/video/av"]');
                        for (let inner of innerLinks) {
                            const match = inner.href.match(VIDEO_ID_REGEX);
                            if (match) {
                                targetVid = match[1];
                                console.log("[Bili快捷收藏] Video scanned", targetVid);
                                break;
                            }
                        }
                    }
                }
                if (targetVid) break;
            }
        }

        if (targetVid) {
            e.preventDefault();
            e.stopPropagation();
            triggerFavorite(targetVid);
        } else {
            console.warn("[Bili快捷收藏] Cannot find any video links.");
        }
    }, true);


    function deepQuerySelector(selector) {
        let queue = [document];
        while(queue.length > 0) {
            let node = queue.shift();
            let el = node.querySelector(selector);
            if (el) return el;

            let all = node.querySelectorAll('*');
            for(let child of all) {
                if(child.shadowRoot) queue.push(child.shadowRoot);
            }
        }
        return null;
    }

    const isVideoPage = window.location.pathname.includes('/video/') || window.location.pathname.includes('/list/');
    const btn = document.createElement('div');

    if (isVideoPage) {
        btn.id = 'quick-fav-overlay-btn';
        btn.title = "【左键】一键加入指定收藏夹\n【右键】更改目标收藏夹";
        btn.style.cssText = `
            position: absolute; display: none; align-items: center; justify-content: center;
            cursor: pointer; color: #61666d; font-size: 14px; transition: color 0.2s;
            user-select: none; white-space: nowrap; z-index: 2147483647;
        `;
        btn.innerHTML = `
            <svg style="width: 22px; height: 22px; margin-right: 6px; fill: currentColor;" viewBox="0 0 1024 1024">
                <path d="M512 758.8l-231.2 121.6 44.1-257.6-187.2-182.4 258.6-37.6L512 165.6l115.6 234.4 258.6 37.6-187.2 182.4 44.1 257.6z"/>
            </svg>
            <span style="font-weight: 500;">一键收藏</span>
        `;
        btn.onmouseenter = () => { btn.style.color = '#00aeec'; };
        btn.onmouseleave = () => { btn.style.color = '#61666d'; };

        btn.onclick = () => {
            const match = window.location.href.match(VIDEO_ID_REGEX);
            if (match) {
                triggerFavorite(match[1]);
            } else {
                showToast('❌ 无法从当前地址获取视频ID', true);
            }
        };
        btn.oncontextmenu = (e) => { e.preventDefault(); openSettings(); };

        document.documentElement.appendChild(btn);

        function syncPosition() {
            if (document.fullscreenElement) {
                btn.style.display = 'none';
                requestAnimationFrame(syncPosition);
                return;
            }
            const toolbarLeft = deepQuerySelector('.video-toolbar-left, .toolbar-left');
            if (toolbarLeft && toolbarLeft.lastElementChild) {
                const targetRect = toolbarLeft.lastElementChild.getBoundingClientRect();
                if (targetRect.width > 0 && targetRect.height > 0) {
                    btn.style.display = 'flex';
                    btn.style.left = (targetRect.right + window.scrollX + 24) + 'px';
                    btn.style.top = (targetRect.top + window.scrollY) + 'px';
                    btn.style.height = targetRect.height + 'px';
                } else {
                    btn.style.display = 'none';
                }
            } else {
                btn.style.display = 'none';
            }
            requestAnimationFrame(syncPosition);
        }
        requestAnimationFrame(syncPosition);
    }


    async function triggerFavorite(vid) {
        if (isProcessing) return;
        const targetFolderId = GM_getValue('target_folder_id');
        if (!targetFolderId) {
            showToast("💡 初次使用，请先选择一键收藏的目标文件夹！");
            openSettings();
            return;
        }
        await addToFavorites(vid, targetFolderId);
    }

    async function addToFavorites(vid, folderId) {
        isProcessing = true;
        try {
            const uid = getCookie('DedeUserID');
            const csrf = getCookie('bili_jct');

            if (!uid || !csrf) {
                showToast("❌ 未检测到登录状态，请先登录！", true);
                return;
            }

            const folderName = GM_getValue('target_folder_name', '未知文件夹');
            showToast(`⏳ 正在将视频加入【${folderName}】...`);

            let aid = vid;
            if (vid.toUpperCase().startsWith('BV')) {
                const viewRes = await fetchApi(`https://api.bilibili.com/x/web-interface/view?bvid=${vid}`);
                if (viewRes.code !== 0) {
                    showToast(`❌ 获取视频信息失败: ${viewRes.message}`, true);
                    return;
                }
                aid = viewRes.data.aid;
            } else if (vid.toLowerCase().startsWith('av')) {
                aid = vid.slice(2);
            }

            const params = new URLSearchParams();
            params.append('rid', aid);
            params.append('type', 2);
            params.append('add_media_ids', folderId);
            params.append('del_media_ids', '');
            params.append('csrf', csrf);

            const addRes = await fetchApi(`https://api.bilibili.com/x/v3/fav/resource/deal`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Origin': 'https://www.bilibili.com',
                    'Referer': window.location.href
                },
                data: params.toString()
            });

            if (addRes.code === 0) {
                showToast(`✅ 已成功加入【${folderName}】！`);
            } else if (addRes.code === 11201) {
                showToast(`⚠️ 视频已经在【${folderName}】中！`);
            } else {
                showToast(`❌ 收藏失败: ${addRes.message}`, true);
            }
        } catch (error) {
            console.error("[双端一键收藏]", error);
            showToast("❌ 发生网络错误，请看控制台", true);
        } finally {
            setTimeout(() => { isProcessing = false; }, 600);
        }
    }

    async function openSettings() {
        const uid = getCookie('DedeUserID');
        if (!uid) {
            showToast("❌ 请先登录！", true);
            return;
        }

        showToast("⏳ 正在获取收藏夹...");
        try {
            const res = await fetchApi(`https://api.bilibili.com/x/v3/fav/folder/created/list-all?up_mid=${uid}`);
            if (res.code !== 0 || !res.data || !res.data.list) {
                showToast("❌ 获取收藏夹失败", true);
                return;
            }
            renderSettingsModal(res.data.list);
        } catch (e) {
            showToast("❌ 网络错误", true);
        }
    }

    function renderSettingsModal(folders) {
        const existing = document.getElementById('qf-settings-modal');
        if (existing) existing.remove();

        const currentFavId = GM_getValue('target_folder_id');

        const overlay = document.createElement('div');
        overlay.id = 'qf-settings-modal';
        overlay.style.cssText = 'position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(0,0,0,0.6); z-index: 2147483647; display: flex; align-items: center; justify-content: center;';

        const box = document.createElement('div');
        box.style.cssText = 'background: #fff; border-radius: 8px; width: 340px; padding: 24px; box-shadow: 0 4px 20px rgba(0,0,0,0.3); font-family: sans-serif;';

        let listHtml = folders.map(f => `
            <label style="display: flex; align-items: center; padding: 10px 8px; cursor: pointer; border-bottom: 1px solid #f0f0f0; color: #18191C; font-size: 15px; transition: background 0.2s;">
                <input type="radio" name="qf_folder" value="${f.id}" data-name="${f.title}" ${currentFavId === f.id ? 'checked' : ''} style="margin-right: 12px; transform: scale(1.2);">
                ${f.title}
            </label>
        `).join('');

        box.innerHTML = `
            <h3 style="margin: 0 0 16px 0; font-size: 18px; color: #18191C;">选择“快捷收藏”目标</h3>
            <div style="max-height: 350px; overflow-y: auto; margin-bottom: 20px; border-top: 1px solid #f0f0f0;">
                ${listHtml}
            </div>
            <div style="display: flex; justify-content: flex-end; gap: 12px;">
                <button id="qf-cancel" style="padding: 8px 16px; border: none; background: #f4f4f4; color: #61666d; border-radius: 6px; cursor: pointer; font-size: 14px;">取消</button>
                <button id="qf-save" style="padding: 8px 16px; border: none; background: #00aeec; color: #fff; border-radius: 6px; cursor: pointer; font-size: 14px;">保存设置</button>
            </div>
        `;

        const labels = box.querySelectorAll('label');
        labels.forEach(l => {
            l.onmouseenter = () => l.style.backgroundColor = '#f4f4f4';
            l.onmouseleave = () => l.style.backgroundColor = 'transparent';
        });

        overlay.appendChild(box);
        document.body.appendChild(overlay);

        document.getElementById('qf-cancel').onclick = () => overlay.remove();
        document.getElementById('qf-save').onclick = () => {
            const checked = overlay.querySelector('input[name="qf_folder"]:checked');
            if (checked) {
                GM_setValue('target_folder_id', parseInt(checked.value));
                GM_setValue('target_folder_name', checked.dataset.name);
                showToast(`✅ 设置完毕！以后将自动收藏至：${checked.dataset.name}`);
                overlay.remove();
            } else {
                showToast("⚠️ 请至少选择一个收藏夹！", true);
            }
        };
    }

    function showToast(msg, isError = false) {
        const toastId = 'bili-quick-fav-toast-v8';
        let toast = document.getElementById(toastId);
        if (!toast) {
            toast = document.createElement('div');
            toast.id = toastId;
            toast.style.cssText = `
                position: fixed; top: 80px; left: 50%; transform: translateX(-50%);
                background: ${isError ? 'rgba(220, 38, 38, 0.95)' : 'rgba(0, 0, 0, 0.85)'};
                color: #fff; padding: 12px 24px; border-radius: 8px; z-index: 2147483647;
                font-size: 15px; pointer-events: none; transition: all 0.3s;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3); text-align: center;
            `;
            document.documentElement.appendChild(toast);
        }
        toast.textContent = msg;
        toast.style.backgroundColor = isError ? 'rgba(220, 38, 38, 0.95)' : 'rgba(0, 0, 0, 0.85)';
        toast.style.opacity = '1';
        toast.style.top = '80px';

        if (toast.hideTimeout) clearTimeout(toast.hideTimeout);
        toast.hideTimeout = setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.top = '60px';
        }, 3000);
    }

    function fetchApi(url, options = {}) {
        return new Promise((resolve, reject) => {
            GM_xmlhttpRequest({
                method: options.method || 'GET',
                url: url,
                headers: options.headers || {},
                data: options.data || null,
                responseType: 'json',
                onload: (res) => {
                    if (res.status === 200) {
                        try {
                            const data = typeof res.response === 'string' ? JSON.parse(res.response) : res.response;
                            resolve(data);
                        } catch (e) { reject(new Error('JSON Error')); }
                    } else {
                        reject(new Error(`HTTP Error: ${res.status}`));
                    }
                },
                onerror: (err) => reject(err)
            });
        });
    }

})();