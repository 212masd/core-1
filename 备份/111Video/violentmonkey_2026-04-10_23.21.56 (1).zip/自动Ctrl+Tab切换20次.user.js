// ==UserScript==
// @name         自动Ctrl+Tab切换20次
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  点击按钮自动按Ctrl+Tab 20次，切换标签页
// @author       豆包
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const btn = document.createElement('button');
    btn.textContent = '🔀 自动切换标签20次';
    btn.style.cssText = `
        position: fixed;
        top: 50px;
        left: 10px;
        z-index: 999999;
        padding: 10px 16px;
        background: #007bff;
        color: white;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 14px;
    `;
    document.body.appendChild(btn);

    btn.onclick = function() {
        let count = 0;
        const maxCount = 20;
        const delay = 300;

        const interval = setInterval(() => {
            if (count >= maxCount) {
                clearInterval(interval);
                alert("已切换完成 20 次！");
                return;
            }

            // 模拟 Ctrl+Tab
            document.dispatchEvent(new KeyboardEvent('keydown', {
                key: 'Tab', ctrlKey: true, bubbles: true
            }));
            document.dispatchEvent(new KeyboardEvent('keyup', {
                key: 'Tab', ctrlKey: true, bubbles: true
            }));

            count++;
        }, delay);
    };
})();