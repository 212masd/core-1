// ==UserScript==
// @name         左上角按钮·后台打开所有视频
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  左上角出现按钮，按住一键后台打开当前页面所有视频链接
// @author       you
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // 1. 创建左上角固定按钮
    const btn = document.createElement('div');
    btn.innerText = '打开所有视频';
    btn.style.cssText = `
        position: fixed;
        top: 10px;
        left: 10px;
        z-index: 999999;
        padding: 8px 12px;
        background: #007bff;
        color: #fff;
        border-radius: 6px;
        cursor: pointer;
        font-size: 14px;
        user-select: none;
    `;

    // 2. 点击/按住时：提取页面所有视频链接并后台打开
    function openAllVideosInBackground() {
        // 收集所有可能的视频链接
        const links = new Set();

        // 匹配所有带视频特征的 a 标签
        document.querySelectorAll('a[href*="video"], a[href*="/video/"], a[href*=".mp4"], a[href*=".m3u8"]').forEach(a => {
            if (a.href && a.href.startsWith('http') && !a.href.includes('javascript')) {
                links.add(a.href);
            }
        });

        // 匹配 video 标签的 src
        document.querySelectorAll('video').forEach(v => {
            if (v.src && v.src.startsWith('http')) {
                links.add(v.src);
            }
        });

        // 后台打开（不跳转、不聚焦）
        links.forEach(url => {
            window.open(url, '_blank', 'noopener noreferrer');
        });

        alert(`已在后台打开 ${links.size} 个视频链接`);
    }

    // 支持点击 / 按住
    btn.addEventListener('click', openAllVideosInBackground);
    btn.addEventListener('mousedown', openAllVideosInBackground);

    document.body.appendChild(btn);
})();