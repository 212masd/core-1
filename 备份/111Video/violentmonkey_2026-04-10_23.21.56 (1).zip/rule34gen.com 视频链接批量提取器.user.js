// ==UserScript==
// @name         rule34gen.com 视频链接批量提取器
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  输入数字自动抓取前N页视频链接，可拖动折叠缩放
// @author       assistant
// @match         *://*/*
// @grant        GM_addStyle
// @grant        GM_xmlhttpRequest
// @connect      rule34gen.com
// ==/UserScript==

(function() {
    'use strict';

    // 面板样式
    GM_addStyle(`
#linkPanel {
    position: fixed;
    top: 50px;
    left: 20px;
    width: 360px;
    background: #111;
    color: #fff;
    border-radius: 10px;
    padding: 12px;
    z-index: 999999;
    resize: both;
    overflow: hidden;
    min-width: 320px;
    max-width: 600px;
    box-shadow: 0 0 15px rgba(0,0,0,0.7);
    font-size: 14px;
    user-select: none;
}
#panelHead {
    padding: 8px;
    background: #333;
    border-radius: 6px;
    display: flex;
    justify-content: space-between;
    cursor: move;
}
#toggleBtn {
    padding: 2px 6px;
    cursor: pointer;
    background: #555;
    border: none;
    color: #fff;
    border-radius: 4px;
}
#panelBody {
    margin-top: 10px;
}
.control {
    display: flex;
    gap: 8px;
    align-items: center;
    margin-bottom: 10px;
}
.control input {
    width: 70px;
    padding: 6px;
    border-radius: 6px;
    border: none;
}
.control button {
    padding: 6px 10px;
    background: #0078d4;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}
#resultArea {
    height: 280px;
    overflow-y: auto;
    background: #1a1a1a;
    padding: 10px;
    border-radius: 6px;
    white-space: pre-wrap;
    user-select: text;
}
`);

    // 面板结构
    const panel = document.createElement('div');
    panel.id = 'linkPanel';
    panel.innerHTML = `
<div id="panelHead">
    <span>rule34gen 视频链接提取</span>
    <button id="toggleBtn">折叠</button>
</div>
<div id="panelBody">
    <div class="control">
        <label>抓取前N页：</label>
        <input type="number" id="pageCount" placeholder="输入数字" min="1" value="3">
        <button id="startBtn">开始提取</button>
        <button id="copyBtn">复制全部</button>
    </div>
    <div id="resultArea"></div>
</div>
`;
    document.body.appendChild(panel);

    // 拖动
    let drag = false, x = 0, y = 0;
    const head = document.getElementById('panelHead');
    head.addEventListener('mousedown', e => {
        drag = true;
        x = e.clientX - panel.offsetLeft;
        y = e.clientY - panel.offsetTop;
    });
    document.addEventListener('mousemove', e => {
        if (!drag) return;
        panel.style.left = e.clientX - x + 'px';
        panel.style.top = e.clientY - y + 'px';
    });
    document.addEventListener('mouseup', () => drag = false);

    // 折叠
    const body = document.getElementById('panelBody');
    const toggle = document.getElementById('toggleBtn');
    toggle.addEventListener('click', () => {
        const show = body.style.display !== 'none';
        body.style.display = show ? 'none' : 'block';
        toggle.textContent = show ? '展开' : '折叠';
    });

    // 提取单页链接
    function extract(html) {
        const urls = [];
        const reg = /https?:\/\/rule34gen\.com\/video\/\d+\/[a-zA-Z0-9_-]+/g;
        let match;
        while ((match = reg.exec(html)) !== null) {
            urls.push(match[0]);
        }
        return [...new Set(urls)];
    }

    // 批量抓取
    async function start() {
        const total = parseInt(document.getElementById('pageCount').value) || 1;
        const resultArea = document.getElementById('resultArea');
        resultArea.textContent = '正在抓取...\n';

        const all = [];
        for (let i = 1; i <= total; i++) {
            const url = `https://rule34gen.com/${i}/`;
            try {
                const html = await fetchPage(url);
                const links = extract(html);
                all.push(`=== 第 ${i} 页 ===`);
                all.push(...links);
                resultArea.textContent = all.join('\n');
                await delay(800);
            } catch (e) {
                all.push(`=== 第 ${i} 页 加载失败 ===`);
            }
        }
        resultArea.textContent = all.join('\n');
    }

    // 请求页面
    function fetchPage(url) {
        return new Promise((resolve, reject) => {
            GM_xmlhttpRequest({
                method: 'GET',
                url: url,
                onload: res => resolve(res.responseText),
                onerror: reject
            });
        });
    }

    function delay(ms) {
        return new Promise(r => setTimeout(r, ms));
    }

    // 复制
    document.getElementById('copyBtn').addEventListener('click', () => {
        const text = document.getElementById('resultArea').textContent;
        navigator.clipboard.writeText(text).then(() => alert('已复制'));
    });

    document.getElementById('startBtn').addEventListener('click', start);
})();