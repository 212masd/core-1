// ==UserScript==
// @name         抖音全页面·左上角链接抓取面板（带刷新）
// @namespace    http://tampermonkey.net/
// @version      3.0
// @description  左上角固定面板，全抖音通用，抓取所有视频链接+作者主页，带刷新按钮，单条/批量复制
// @author       豆包
// @match        *://www.douyin.com/*
// @match        *://v.douyin.com/*
// @grant        GM_setClipboard
// @grant        GM_addStyle
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    GM_addStyle(`
        #dyToolPanel {
            position: fixed;
            top: 10px;
            left: 10px;
            width: 360px;
            max-height: 80vh;
            background: #171717;
            color: #fff;
            border-radius: 10px;
            padding: 12px;
            z-index: 999999;
            box-shadow: 0 0 12px rgba(0,0,0,0.7);
            overflow-y: auto;
            font-size: 12px;
            line-height: 1.5;
        }
        #dyToolPanel .head {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        #dyToolPanel .title {
            font-weight: bold;
            color: #ff4e79;
            font-size: 14px;
        }
        #dyToolPanel #refreshBtn {
            background: #ff4e79;
            color: #fff;
            border: none;
            border-radius: 6px;
            padding: 4px 10px;
            cursor: pointer;
            font-size: 12px;
        }
        #dyToolPanel .item {
            border-bottom: 1px solid #333;
            padding: 6px 0;
        }
        #dyToolPanel .v-url, #dyToolPanel .a-url {
            color: #ccc;
            word-break: break-all;
            margin: 2px 0;
        }
        #dyToolPanel .copyBtn {
            display: inline-block;
            background: #444;
            color: #fff;
            border-radius: 4px;
            padding: 2px 6px;
            margin-right: 4px;
            cursor: pointer;
            font-size: 11px;
        }
        #dyToolPanel #copyAllBtn {
            background: #ff4e79;
            color: #fff;
            text-align: center;
            padding: 6px;
            border-radius: 6px;
            cursor: pointer;
            margin-top: 10px;
            font-weight: bold;
        }
        #dyToolPanel #listArea {
            padding-bottom: 10px;
        }
    `);

    // 创建面板
    const panel = document.createElement('div');
    panel.id = 'dyToolPanel';
    panel.innerHTML = `
        <div class="head">
            <div class="title">抖音视频&作者抓取</div>
            <button id="refreshBtn">刷新抓取</button>
        </div>
        <div id="listArea">加载中，请稍候...</div>
        <div id="copyAllBtn">一键复制全部</div>
    `;
    document.body.appendChild(panel);

    const listArea = document.getElementById('listArea');
    const data = [];

    // 抓取函数
    function collect() {
        listArea.innerHTML = '正在抓取...';
        data.length = 0;

        const cards = document.querySelectorAll('[data-e2e="feed-card"], [data-e2e="video-card"], .xg-video-container');
        if (!cards.length) {
            listArea.innerHTML = '未找到视频';
            return;
        }

        let html = '';
        cards.forEach((card, i) => {
            // 视频链接
            const vNode = card.querySelector('a[href*="/video/"]');
            const v = vNode ? vNode.href.split('?')[0] : '无';

            // 作者链接
            const aNode = card.querySelector('a[href*="/user/"]');
            const a = aNode ? aNode.href.split('?')[0] : '无';

            data.push({ i, v, a });

            html += `
            <div class="item">
                <div>${i+1}.</div>
                <div class="v-url">视频：${v}</div>
                <div class="a-url">作者：${a}</div>
                <div>
                    <span class="copyBtn" data-t="v" data-i="${i}">复制视频</span>
                    <span class="copyBtn" data-t="a" data-i="${i}">复制作者</span>
                </div>
            </div>
            `;
        });

        listArea.innerHTML = html;

        // 单条复制
        document.querySelectorAll('.copyBtn').forEach(b => {
            b.onclick = () => {
                const { t, i } = b.dataset;
                const txt = t === 'v' ? data[i].v : data[i].a;
                GM_setClipboard(txt);
                b.textContent = '✅已复制';
                setTimeout(() => b.textContent = t === 'v' ? '复制视频' : '复制作者', 900);
            };
        });
    }

    // 刷新按钮
    document.getElementById('refreshBtn').onclick = collect;

    // 批量复制
    document.getElementById('copyAllBtn').onclick = () => {
        let txt = '';
        data.forEach(d => {
            txt += `[${d.i+1}] 视频：${d.v}\n作者：${d.a}\n\n`;
        });
        GM_setClipboard(txt);
        alert('已复制全部链接到剪贴板！');
    };

    // 初始加载
    setTimeout(collect, 1200);
})();