// ==UserScript==
// @name        New script 91porn.com
// @namespace   Violentmonkey Scripts
// @match       https://91porn.com/view_video.php*
// @grant       none
// @version     1.0
// @author      -
// @description 2026/3/28 01:38:51
// ==/UserScript==
// ==UserScript==
// @name         B站搜索·自定义页数批量提取视频链接
// @namespace    http://tampermonkey.net/
// @version      2.0
// @description  输入关键词 + 页数，自动抓取多页B站视频链接
// @author       assistant
// @match        *://*/*
// @grant        GM_xmlhttpRequest
// @grant        GM_setClipboard
// @connect      search.bilibili.com
// ==/UserScript==

(function() {
    'use strict';

    // 创建悬浮面板
    const panel = document.createElement('div');
    panel.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 99999;
        background: #fff;
        padding: 12px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0,0,0,0.2);
        width: 240px;
    `;

    // 关键词输入
    const keywordInput = document.createElement('input');
    keywordInput.placeholder = "输入搜索关键词";
    keywordInput.style.cssText = `
        width: 100%;
        padding: 6px;
        margin-bottom: 8px;
        box-sizing: border-box;
    `;

    // 页数输入
    const pageInput = document.createElement('input');
    pageInput.placeholder = "抓取页数（如 3）";
    pageInput.type = "number";
    pageInput.min = "1";
    pageInput.value = "1";
    pageInput.style.cssText = `
        width: 100%;
        padding: 6px;
        margin-bottom: 8px;
        box-sizing: border-box;
    `;

    // 开始按钮
    const btn = document.createElement('button');
    btn.textContent = "开始抓取视频链接";
    btn.style.cssText = `
        width: 100%;
        padding: 8px;
        background: #fb7299;
        color: #fff;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-weight: bold;
    `;

    // 组装面板
    panel.appendChild(keywordInput);
    panel.appendChild(pageInput);
    panel.appendChild(btn);
    document.body.appendChild(panel);

    // 点击开始
    btn.onclick = async function() {
        const keyword = keywordInput.value.trim();
        const maxPage = parseInt(pageInput.value) || 1;

        if (!keyword) {
            alert("请输入关键词");
            return;
        }

        btn.disabled = true;
        btn.textContent = "正在抓取第 1 页...";

        const allLinks = [];

        // 逐页抓取
        for (let page = 1; page <= maxPage; page++) {
            btn.textContent = `正在抓取第 ${page}/${maxPage} 页...`;

            const searchUrl = `https://search.bilibili.com/all?keyword=${encodeURIComponent(keyword)}&page=${page}`;

            try {
                const html = await fetchPage(searchUrl);
                const links = parseLinks(html);
                allLinks.push(...links);
            } catch (e) {
                console.error("第" + page + "页失败", e);
            }
        }

        // 去重
        const uniqueLinks = [...new Set(allLinks)];

        // 结果
        const resultText = uniqueLinks.join("\n");
        GM_setClipboard(resultText);

        alert(`抓取完成！
关键词：${keyword}
页数：${maxPage}
共获取视频链接：${uniqueLinks.length} 个

已复制到剪贴板`);

        btn.disabled = false;
        btn.textContent = "开始抓取视频链接";
    };

    // 请求页面
    function fetchPage(url) {
        return new Promise((resolve, reject) => {
            GM_xmlhttpRequest({
                method: "GET",
                url: url,
                headers: {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
                },
                onload: res => resolve(res.responseText),
                onerror: reject
            });
        });
    }

    // 提取 BV 链接
    function parseLinks(html) {
        const reg = /https:\/\/www\.bilibili\.com\/video\/BV[a-zA-Z0-9]+/g;
        return html.match(reg) || [];
    }

})();