// ==UserScript==
// @name         宪法卫士速过练习工具
// @namespace    http://mcskin.cn
// @version      0.1
// @description  快速完善宪法卫士中的练习
// @author       Michael
// @match        https://static.qspfw.moe.gov.cn/xf2022/learn-practice.html*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=moe.gov.cn
// @grant        none
// @license      MIT
// ==/UserScript==

(function() {
    'use strict';
    window.showAnswer = function() {
        let answer = questionBank_answer;
        $('.item[data-check='+ answer +']').trigger("click");
    }
    setTimeout(function () {
        let oldNext = window.nextQuestion
        window.nextQuestion = function () {
            oldNext();
            showAnswer();
        }
        showAnswer();
    },1000);
})();